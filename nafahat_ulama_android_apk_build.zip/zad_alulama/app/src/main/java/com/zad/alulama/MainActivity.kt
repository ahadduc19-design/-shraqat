package com.zad.alulama

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Cream = Color(0xFFF6F3EA)
private val Green = Color(0xFF205747)
private val Ink = Color(0xFF24332D)

 data class ScholarQuote(val id: Int, val scholar: String, val text: String, val source: String, val category: String)

/** Offline starter library. Verify wording and edition-specific page numbers before release. */
private val quotes = listOf(
    ScholarQuote(1, "الإمام الشافعي", "العلم ما نفع، ليس العلم ما حُفِظ.", "الخطيب البغدادي، اقتضاء العلم العمل؛ يُراجع اختلاف ألفاظ النسبة والطبعات قبل النشر.", "طلب العلم"),
    ScholarQuote(2, "الإمام النووي", "ينبغي لطالب العلم أن يطهر قلبه من الأدناس؛ ليصلح لقبول العلم وحفظه واستثماره.", "النووي، المجموع شرح المهذب، المقدمة، باب آداب العالم والمتعلم.", "آداب العلم"),
    ScholarQuote(3, "ابن جماعة الكناني", "ينبغي للطالب أن يغتنم أوقات عمره في التحصيل، ولا يغتر بخدع التسويف والتأميل.", "ابن جماعة، تذكرة السامع والمتكلم في أدب العالم والمتعلم، فصل آداب الطالب في نفسه.", "طلب العلم"),
    ScholarQuote(4, "ابن القيم", "فإن العلم حياة ونور، والجهل موت وظلمة.", "ابن القيم، مفتاح دار السعادة؛ يُراجع موضع العبارة ولفظها في الطبعة المعتمدة قبل النشر.", "العلم والعمل"),
    ScholarQuote(5, "ابن رجب الحنبلي", "العلم النافع يدل على أمرين: على معرفة الله وما يستحقه من الأسماء الحسنى والصفات العلى والأفعال الباهرة، وعلى معرفة ما يحبه ويرضاه وما يكرهه ويسخطه.", "ابن رجب، فضل علم السلف على علم الخلف، في بيان حقيقة العلم النافع.", "العقيدة"),
    ScholarQuote(6, "الإمام الذهبي", "إن العلم ليس بكثرة الرواية، ولكنه نور يقذفه الله في القلب.", "الذهبي، سير أعلام النبلاء؛ تُراجع نسبة اللفظ وموضعه في الطبعة المعتمدة قبل النشر.", "العلم والعمل"),
    ScholarQuote(7, "ابن تيمية", "العبادة اسم جامع لكل ما يحبه الله ويرضاه من الأقوال والأعمال الباطنة والظاهرة.", "ابن تيمية، العبودية، تعريف العبادة في أول الرسالة.", "العبادة"),
    ScholarQuote(8, "ابن قدامة المقدسي", "واعلم أن العلم والعمل توأمان، وأمهما لا ينفع أحدهما بدون الآخر.", "ابن قدامة، مختصر منهاج القاصدين؛ يُراجع النص الحرفي في الطبعة المعتمدة قبل النشر.", "العلم والعمل")
)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationTools.createChannel(this)
        setContent { NafahatApp() }
    }
    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

@Composable
private fun NafahatApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nafahat", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("الرئيسية") }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("الكل") }
    var morning by remember { mutableStateOf(prefs.getString("time1", "08:00") ?: "08:00") }
    var noon by remember { mutableStateOf(prefs.getString("time2", "14:00") ?: "14:00") }
    var evening by remember { mutableStateOf(prefs.getString("time3", "20:00") ?: "20:00") }
    var saved by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    val filtered = quotes.filter { q ->
        (category == "الكل" || q.category == category) &&
            (q.text.contains(query, true) || q.scholar.contains(query, true) || q.source.contains(query, true))
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Cream, surface = Color.White)) {
        Scaffold(containerColor = Cream, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("الرئيسية", "الأقوال", "المفضلة", "الإعدادات").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = { Text(when(item) { "الرئيسية" -> "⌂"; "الأقوال" -> "❖"; "المفضلة" -> "♡"; else -> "⚙" }, fontSize = 20.sp) }, label = { Text(item) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
                Text("نفحات العلماء", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = Green)
                Text("نفحات من كلام علماء أهل السنة", color = Ink, fontSize = 15.sp)
                when (tab) {
                    "الرئيسية" -> {
                        val quote = quotes[(java.time.LocalDate.now().dayOfYear - 1) % quotes.size]
                        QuoteCard(quote, favorites.contains(quote.id.toString()), { favorites = toggleFavorite(prefs, favorites, quote.id) })
                        Text("من مكتبة الأقوال", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                        quotes.take(3).forEach { q -> QuoteCard(q, favorites.contains(q.id.toString()), { favorites = toggleFavorite(prefs, favorites, q.id) }) }
                        OutlinedButton(onClick = { tab = "الأقوال" }, modifier = Modifier.fillMaxWidth()) { Text("تصفح جميع الأقوال") }
                    }
                    "الأقوال" -> {
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("ابحث عن عالم أو عبارة أو مصدر") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("الكل", "طلب العلم", "آداب العلم", "العلم والعمل", "العقيدة", "العبادة").forEach { c ->
                                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
                            }
                        }
                        filtered.forEach { q -> QuoteCard(q, favorites.contains(q.id.toString()), { favorites = toggleFavorite(prefs, favorites, q.id) }) }
                        if (filtered.isEmpty()) Text("لا توجد نتائج مطابقة.", color = Ink)
                    }
                    "المفضلة" -> {
                        Text("الأقوال المحفوظة", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                        quotes.filter { favorites.contains(it.id.toString()) }.forEach { q -> QuoteCard(q, true, { favorites = toggleFavorite(prefs, favorites, q.id) }) }
                        if (favorites.isEmpty()) Text("لم تحفظ أقوالاً بعد. اضغط علامة القلب بجانب أي قول لإضافته هنا.", color = Ink, lineHeight = 24.sp)
                    }
                    else -> {
                        Text("مواعيد التذكير اليومية", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("اختر ثلاثة أوقات. يعتمد توقيت وصول الإشعار على إعدادات النظام وتوفير البطارية.", color = Color.Gray, lineHeight = 22.sp)
                        TimeField("الإشعار الأول", morning) { morning = it; saved = false }
                        TimeField("الإشعار الثاني", noon) { noon = it; saved = false }
                        TimeField("الإشعار الثالث", evening) { evening = it; saved = false }
                        Button(onClick = {
                            val times = listOf(morning, noon, evening)
                            if (times.all { it.matches(Regex("^([01]\\d|2[0-3]):[0-5]\\d$")) }) {
                                prefs.edit().putString("time1", morning).putString("time2", noon).putString("time3", evening).apply()
                                NotificationTools.scheduleAll(context, times); saved = true
                            } else saved = false
                        }, modifier = Modifier.fillMaxWidth()) { Text("حفظ المواعيد وتفعيلها") }
                        if (saved) Text("تم حفظ المواعيد وتفعيل التذكيرات.", color = Green, fontWeight = FontWeight.SemiBold)
                        Divider()
                        Text("حول التطبيق", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("يعمل التطبيق دون اتصال بالإنترنت، وتُحفظ المفضلة ومواعيد التذكير على جهازك. لا يجمع التطبيق بيانات شخصية في هذه النسخة.", color = Ink, lineHeight = 23.sp)
                        Text("تنبيه تحريري: بعض النقول تحتاج مراجعة لفظها وموضعها على طبعة محددة قبل النشر العام. لا تعتمد هذه النسخة للنشر قبل إكمال مراجعة المصادر.", color = Color(0xFF8A4B16), lineHeight = 22.sp)
                    }
                }
            }
        }
    }
}

private fun toggleFavorite(context: Context, current: Set<String>, id: Int): Set<String> {
    val updated = if (current.contains(id.toString())) current - id.toString() else current + id.toString()
    context.getSharedPreferences("nafahat", Context.MODE_PRIVATE).edit().putStringSet("favorites", updated).apply()
    return updated
}

@Composable
private fun QuoteCard(quote: ScholarQuote, favorite: Boolean, onFavorite: () -> Unit) {
    val context = LocalContext.current
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(quote.scholar, modifier = Modifier.weight(1f), color = Green, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "حفظ في المفضلة", tint = if (favorite) Color(0xFFB33A4A) else Green) }
            }
            Text("«${quote.text}»", color = Ink, fontSize = 18.sp, lineHeight = 29.sp)
            Text("التصنيف: ${quote.category}", color = Green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Divider(color = Cream)
            Text("المصدر: ${quote.source}", color = Color.DarkGray, fontSize = 12.sp, lineHeight = 19.sp)
            OutlinedButton(onClick = { shareQuoteAsImage(context, quote) }, modifier = Modifier.fillMaxWidth()) {
                Text("مشاركة القول كصورة  ↗")
            }
        }
    }
}

private fun shareQuoteAsImage(context: Context, quote: ScholarQuote) {
    val width = 1080
    val height = 1350
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.rgb(246, 243, 234))
    val green = android.graphics.Color.rgb(32, 87, 71)
    val ink = android.graphics.Color.rgb(36, 51, 45)
    val accent = android.graphics.Color.rgb(191, 155, 78)
    val card = RectF(58f, 58f, 1022f, 1292f)
    val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE }
    canvas.drawRoundRect(card, 42f, 42f, cardPaint)
    val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; strokeWidth = 8f; strokeCap = Paint.Cap.ROUND }
    canvas.drawLine(150f, 150f, 930f, 150f, linePaint)

    val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = green; textSize = 48f; typeface = Typeface.create("sans-serif", Typeface.BOLD); textAlign = Paint.Align.CENTER }
    canvas.drawText("نفحات العلماء", width / 2f, 230f, titlePaint)
    val scholarPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = green; textSize = 38f; typeface = Typeface.create("sans-serif", Typeface.BOLD); textAlign = Paint.Align.CENTER }
    canvas.drawText(quote.scholar, width / 2f, 330f, scholarPaint)

    val quotePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; textSize = 43f; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
    val quoteLayout = StaticLayout.Builder.obtain("«${quote.text}»", 0, "«${quote.text}»".length, quotePaint, 820)
        .setAlignment(Layout.Alignment.ALIGN_CENTER).setTextDirection(android.text.TextDirectionHeuristics.RTL).setLineSpacing(18f, 1.12f).build()
    canvas.save()
    canvas.translate(130f, 400f)
    quoteLayout.draw(canvas)
    canvas.restore()

    val sourceText = "المصدر: ${quote.source}"
    val sourcePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.DKGRAY; textSize = 25f }
    val sourceLayout = StaticLayout.Builder.obtain(sourceText, 0, sourceText.length, sourcePaint, 820)
        .setAlignment(Layout.Alignment.ALIGN_CENTER).setTextDirection(android.text.TextDirectionHeuristics.RTL).setLineSpacing(8f, 1.0f).build()
    val sourceY = (quoteLayout.height + 485).coerceAtMost(1000)
    canvas.save()
    canvas.translate(130f, sourceY.toFloat())
    sourceLayout.draw(canvas)
    canvas.restore()

    val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = green; textSize = 30f; typeface = Typeface.create("sans-serif", Typeface.BOLD); textAlign = Paint.Align.CENTER }
    canvas.drawText("نفحات العلماء  •  أقوال تُضيء الطريق", width / 2f, 1215f, footerPaint)
    val imagesDir = File(context.cacheDir, "shared_quotes").apply { mkdirs() }
    val imageFile = File(imagesDir, "nafahat_quote_${quote.id}.png")
    FileOutputStream(imageFile).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", imageFile)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_TEXT, "${quote.scholar} — نفحات العلماء")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة القول كصورة"))
}

@Composable
private fun TimeField(label: String, value: String, onValue: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Ink, fontWeight = FontWeight.Medium)
        OutlinedTextField(value = value, onValueChange = { if (it.length <= 5 && it.all { c -> c.isDigit() || c == ':' }) onValue(it) }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("08:30") }, supportingText = { Text("صيغة 24 ساعة، مثل 08:30") })
    }
}

object NotificationTools {
    private const val CHANNEL_ID = "nafahat_daily_quotes"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(android.app.NotificationChannel(CHANNEL_ID, "نفحات العلماء اليومية", android.app.NotificationManager.IMPORTANCE_DEFAULT).apply { description = "تذكيرات يومية بأقوال العلماء" })
        }
    }
    fun scheduleAll(context: Context, times: List<String>) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        times.forEachIndexed { index, time ->
            val parts = time.split(":")
            if (parts.size != 2) return@forEachIndexed
            val hour = parts[0].toIntOrNull() ?: return@forEachIndexed
            val minute = parts[1].toIntOrNull() ?: return@forEachIndexed
            if (hour !in 0..23 || minute !in 0..59) return@forEachIndexed
            val intent = Intent(context, QuoteNotificationReceiver::class.java).putExtra("slot", index)
            val pending = PendingIntent.getBroadcast(context, 700 + index, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val cal = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, hour); set(java.util.Calendar.MINUTE, minute); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1) }
            manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
        }
    }
    fun restore(context: Context) {
        val prefs = context.getSharedPreferences("nafahat", Context.MODE_PRIVATE)
        scheduleAll(context, listOf(prefs.getString("time1", "08:00") ?: "08:00", prefs.getString("time2", "14:00") ?: "14:00", prefs.getString("time3", "20:00") ?: "20:00"))
    }
    fun show(context: Context, slot: Int) {
        createChannel(context)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val quote = quotes[(java.time.LocalDate.now().dayOfYear + slot) % quotes.size]
        val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, CHANNEL_ID) else @Suppress("DEPRECATION") android.app.Notification.Builder(context)
        notification.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("نفحات العلماء — ${quote.scholar}").setContentText(quote.text).setAutoCancel(true)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(100 + slot, notification.build())
    }
}

class QuoteNotificationReceiver : BroadcastReceiver() { override fun onReceive(context: Context, intent: Intent) { NotificationTools.show(context, intent.getIntExtra("slot", 0)) } }
class BootReceiver : BroadcastReceiver() { override fun onReceive(context: Context, intent: Intent) { if (intent.action == Intent.ACTION_BOOT_COMPLETED) NotificationTools.restore(context) } }
