# نفحات العلماء — APK oluşturma kılavuzu

Bu ZIP, Android Studio projesidir; henüz derlenmiş APK dosyası değildir. Bu çalışma ortamında Android SDK/Gradle bulunmadığı için APK'yı burada derleyip test edemedim.

## GitHub Actions ile APK üretme
1. GitHub'da yeni, boş bir repository oluşturun.
2. Bu ZIP'i bilgisayarda çıkarın; içindeki `zad_alulama` klasörünün **içeriğini** repository'ye yükleyin (`.github/workflows/build-apk.yml` dosyası da dahil olmalı).
3. GitHub'da repository → **Actions** bölümüne girin.
4. **Build Android debug APK** iş akışını seçin ve **Run workflow** düğmesine basın.
5. İşlem başarıyla tamamlanınca çalıştırma sayfasının en altındaki **Artifacts** bölümünden `nafahat-ulama-debug-apk` dosyasını indirin.
6. ZIP'i açın; içindeki `app-debug.apk` dosyasını Android telefonunuza gönderip kurun. Android, bilinmeyen kaynaktan kurulum izni isteyebilir.

## Bilmeniz gerekenler
- Bu, telefonda deneme için imzalanan **debug APK**'dır; Google Play'e yayımlanacak sürüm değildir.
- Google Play için ayrıca release anahtarıyla imzalanmış AAB hazırlanmalıdır.
- Her sözün kaynağını ve metnini yayından önce güvenilir basılı/dijital edisyonla doğrulayın.
- Bu proje ortamında derleme çalıştırılmadı; GitHub Actions sonucu ilk gerçek derleme kontrolü olacaktır.
