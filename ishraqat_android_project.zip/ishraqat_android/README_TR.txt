İŞRAKÂT (إشراقات) — Android Studio proje kaynakları

Bu arşiv bir Android uygulama projesidir; henüz derlenmiş APK değildir. Bu çalışma ortamında Android SDK/Gradle derleme ortamı bulunmadığından imzalı APK üretilemedi. Yanlış bir APK bağlantısı vermemek için bu açıkça belirtilmiştir.

İçerik:
- Arapça arayüz (assets/index.html)
- WebView tabanlı Android uygulama kabuğu
- Yerel tarayıcı depolamasıyla oturumlar arasında kullanıcı eklemeleri
- Metin kopyalama/paylaşma
- Renk ve arka plan özelleştirme, galeriden görsel seçme
- PNG kart indirme arayüzü
- Android bildirim izni ve her gün 09:00 / 20:00 için bildirim zamanlama kodu

APK oluşturma:
1. Bilgisayara Android Studio (Android SDK ile) kurun.
2. ZIP'i çıkarıp Android Studio'da `ishraqat_android` klasörünü açın.
3. Gradle eşitlemesinin bitmesini bekleyin ve Android SDK Platform 35'i yükleyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. Test için oluşan APK'yı Android telefona aktarın. Yayın için ayrıca release imzası gerekir.

Notlar:
- Bildirimler Android sürümü, pil optimizasyonu ve izinlere bağlı olarak etkilenebilir; gerçek cihazda test edilmelidir.
- Kart PNG dışa aktarımı WebView üzerinde cihazdan cihaza test edilmelidir.
- Örnek sözler doğrulanmış alıntılar değildir. Kaynakları doğrulanmadan âlimlere nispet edilmemelidir.
