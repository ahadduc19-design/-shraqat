package com.ishraqat.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar

class QuoteNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        NotificationScheduler.createChannel(context)
        val id = intent.getIntExtra("notification_id", 1)
        val line = if (id == 1) "اجعل يومك عامرًا بالعلم والعمل الصالح." else "لحظة تأمل: راجع نيتك وجدّد همتك في طلب العلم."
        val notification = NotificationCompat.Builder(context, NotificationScheduler.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("إشراقات")
            .setContentText(line)
            .setStyle(NotificationCompat.BigTextStyle().bigText(line))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(id, notification) } catch (_: SecurityException) { }
        val hour = intent.getIntExtra("hour", if (id == 1) 9 else 20)
        val minute = intent.getIntExtra("minute", 0)
        NotificationScheduler.scheduleDaily(context, hour, minute, id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            NotificationScheduler.scheduleDaily(context, 9, 0, 1)
            NotificationScheduler.scheduleDaily(context, 20, 0, 2)
        }
    }
}

object NotificationScheduler {
    const val CHANNEL_ID = "ishraqat_daily"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "تذكيرات إشراقات", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "تذكيران يوميان بأوقات ثابتة"
            })
        }
    }
    fun scheduleDaily(context: Context, hour: Int, minute: Int, id: Int) {
        val intent = Intent(context, QuoteNotificationReceiver::class.java).apply {
            putExtra("notification_id", id); putExtra("hour", hour); putExtra("minute", minute)
        }
        val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
            else alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        } catch (_: SecurityException) {
            alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        }
    }
}
